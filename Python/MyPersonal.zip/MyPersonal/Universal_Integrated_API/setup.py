#!/usr/bin/env python
# -*- coidng:UTF-8 -*-

from distutils.core import setup
setup(
	name="Universal_Integrated_API", 
	version="1.0.1", 
	description="Universal Integrated API for CoreOS", 
	author="Cyril", 
	py_modules=[
		"jc.utils",
	])
