#!/usr/bin/env python
# -*- coding:UTF-8 -*-

from jc import utils
# main test for Universal_Integrated_API

utils.test()
print utils.readCMD(["ls"], True)
