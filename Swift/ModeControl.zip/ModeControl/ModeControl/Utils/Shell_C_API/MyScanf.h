//
//  MyScanf.h
//  ModeControl
//
//  Created by coreos on 2/23/19.
//  Copyright © 2019 coreos. All rights reserved.
//

#ifndef MyScanf_h
#define MyScanf_h

#include <stdio.h>

char *MyScanf(void);

// 不支持中文
char *readbuffer(void);

#endif /* MyScanf_h */
