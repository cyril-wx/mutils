//
//  ViewController.swift
//  alertMessage
//
//  Created by coreos on 7/29/19.
//  Copyright © 2019 cyril. All rights reserved.
//

import Cocoa

class ViewController: NSViewController {

	override func viewDidLoad() {
		super.viewDidLoad()

		// Do any additional setup after loading the view.
		
		//if let name = readLine() 	// readline
		//print(CommandLine.argc)
		//print(CommandLine.arguments)
		let argc = CommandLine.argc			// args from 1 to end
		let args = CommandLine.arguments	// args from 1 to end
		
		var msg_info = ""
		var title = ""
		var no = ""
		var yes = ""
		var answer = false
		
		if argc == 4{
			msg_info = args[1]
			no = args[2]
			yes = args[3]
			answer = showMsgBox(msg: msg_info, title: "", no: no, yes: yes)
		}else if argc == 5{
			msg_info = args[1]
			title = args[2]
			no = args[3]
			yes = args[4]
			answer = showMsgBox(msg: msg_info, title: title, no: no, yes: yes)
		}else{
			print("Usage: ./alertMessage MsgInfo Title NO_String YES_String or ./alertMessage MsgInfo NO_String YES_String.")
			exit(255)
		}
		
		if answer {
			print("True")
			exit(0)
		}else{
			print("False")
			exit(1)
		}
	}

	override var representedObject: Any? {
		didSet {
		// Update the view, if already loaded.
		}
	}

	/// 被自动调用的回调方法 - 弹出提示框
	/// - Returns: True: NO, False: YES
	func showMsgBox(msg: String, title: String, no:String="NO", yes:String="YES") -> Bool {
		let alert:NSAlert = NSAlert()
		alert.messageText = "\(title) \(msg)"
		alert.addButton(withTitle: yes)
		alert.addButton(withTitle: no)
		
		alert.alertStyle = NSAlert.Style.critical
		// 弹窗
		//alert.runModal()
		return alert.runModal() == NSApplication.ModalResponse.alertFirstButtonReturn	//(NO 按钮)
	}

}

